Development:
`npm run watch`

Release:
`npx webpack --config webpack.config.js --mode production --output-path release`